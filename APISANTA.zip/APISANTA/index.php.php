<?php
echo "API Santa Funcionando!";
?>